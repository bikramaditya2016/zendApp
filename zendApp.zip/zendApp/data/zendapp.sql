-- phpMyAdmin SQL Dump
-- version 5.0.4
-- https://www.phpmyadmin.net/
--
-- Host: 127.0.0.1
-- Generation Time: May 13, 2021 at 10:52 AM
-- Server version: 10.4.17-MariaDB
-- PHP Version: 7.4.15

SET SQL_MODE = "NO_AUTO_VALUE_ON_ZERO";
START TRANSACTION;
SET time_zone = "+00:00";


/*!40101 SET @OLD_CHARACTER_SET_CLIENT=@@CHARACTER_SET_CLIENT */;
/*!40101 SET @OLD_CHARACTER_SET_RESULTS=@@CHARACTER_SET_RESULTS */;
/*!40101 SET @OLD_COLLATION_CONNECTION=@@COLLATION_CONNECTION */;
/*!40101 SET NAMES utf8mb4 */;

--
-- Database: `zendapp`
--

-- --------------------------------------------------------

--
-- Table structure for table `album`
--

CREATE TABLE `album` (
  `id` int(10) NOT NULL,
  `artist` varchar(255) NOT NULL,
  `title` varchar(255) NOT NULL
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4;

--
-- Dumping data for table `album`
--

INSERT INTO `album` (`id`, `artist`, `title`) VALUES
(1, 'abc from database', 'In My Dreams'),
(2, 'Adele', '21'),
(3, 'Bruce Springsteen', 'Wrecking Ball (Deluxe)'),
(4, 'Lana Del Rey', 'Born To Die'),
(5, 'Gotye', 'Making Mirrors');

-- --------------------------------------------------------

--
-- Table structure for table `departments`
--

CREATE TABLE `departments` (
  `dept_id` int(2) NOT NULL,
  `emp_no` int(4) NOT NULL,
  `dept_no` char(4) NOT NULL,
  `dept_name` varchar(16) NOT NULL
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4;

--
-- Dumping data for table `departments`
--

INSERT INTO `departments` (`dept_id`, `emp_no`, `dept_no`, `dept_name`) VALUES
(1, 1, 'D1', 'EPD'),
(2, 2, 'D2', 'OOT'),
(12, 3, 'EEE', 'Engineering'),
(13, 4, 'EAE', 'IT'),
(14, 5, 'EEE', 'Communication'),
(15, 6, 'EEE', 'Mechanical'),
(16, 7, 'EEE', 'Support');

-- --------------------------------------------------------

--
-- Table structure for table `dept_emp`
--

CREATE TABLE `dept_emp` (
  `dept_emp_id` int(3) NOT NULL,
  `emp_no` int(3) NOT NULL,
  `dept_id` int(3) NOT NULL,
  `from_date` date NOT NULL,
  `to_date` date NOT NULL
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4;

--
-- Dumping data for table `dept_emp`
--

INSERT INTO `dept_emp` (`dept_emp_id`, `emp_no`, `dept_id`, `from_date`, `to_date`) VALUES
(9, 73, 1, '2021-05-09', '2021-05-10'),
(10, 74, 1, '2021-05-03', '2021-05-05'),
(11, 75, 1, '2021-05-01', '2021-05-02'),
(12, 76, 1, '2021-05-02', '2021-05-06'),
(13, 77, 1, '2021-05-09', '2021-05-09'),
(14, 78, 1, '2021-05-13', '2021-05-14'),
(15, 79, 1, '2021-05-09', '2021-05-11'),
(16, 80, 1, '2021-05-09', '2021-05-09'),
(17, 81, 1, '2021-05-09', '2021-05-09'),
(18, 82, 1, '2021-05-10', '2021-05-10'),
(19, 83, 1, '2021-05-10', '2021-05-10');

-- --------------------------------------------------------

--
-- Table structure for table `dept_manager`
--

CREATE TABLE `dept_manager` (
  `dept_manager_id` int(3) NOT NULL,
  `dept_id` int(3) NOT NULL,
  `emp_no` int(3) NOT NULL,
  `from_date` date NOT NULL,
  `to_date` date NOT NULL
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4;

-- --------------------------------------------------------

--
-- Table structure for table `employees`
--

CREATE TABLE `employees` (
  `emp_no` int(5) NOT NULL,
  `birth_date` date NOT NULL,
  `first_name` varchar(30) NOT NULL,
  `last_name` varchar(16) NOT NULL,
  `gender` enum('M','F') NOT NULL,
  `hire_date` date NOT NULL
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4;

--
-- Dumping data for table `employees`
--

INSERT INTO `employees` (`emp_no`, `birth_date`, `first_name`, `last_name`, `gender`, `hire_date`) VALUES
(74, '2021-05-01', 'Shiladitya', 'Konwar', 'M', '2021-05-02'),
(75, '2021-05-09', 'Pritish', 'Konwar', 'M', '2021-05-10'),
(76, '2021-05-09', 'Saranga', 'Bora', 'M', '2021-05-10'),
(77, '2021-05-09', 'Pragya', 'Konwar', 'F', '2021-05-09'),
(78, '2021-05-09', 'Bikramaditya', 'konwar', 'M', '2021-05-09'),
(81, '2021-05-09', 'Bitupan', 'Saikia', 'M', '2021-05-09');

-- --------------------------------------------------------

--
-- Table structure for table `salary`
--

CREATE TABLE `salary` (
  `salary_id` int(3) NOT NULL,
  `emp_no` int(3) NOT NULL,
  `salary` float NOT NULL,
  `from_date` date NOT NULL,
  `to_date` date NOT NULL
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4;

--
-- Dumping data for table `salary`
--

INSERT INTO `salary` (`salary_id`, `emp_no`, `salary`, `from_date`, `to_date`) VALUES
(26, 73, 25000, '2021-05-09', '2021-05-10'),
(27, 74, 31000, '2021-05-03', '2021-05-05'),
(28, 75, 40000, '2021-05-01', '2021-05-02'),
(29, 76, 20000, '2021-05-02', '2021-05-06'),
(30, 77, 12000, '2021-05-09', '2021-05-09'),
(31, 78, 23000, '2021-05-13', '2021-05-14'),
(32, 79, 30000, '2021-05-09', '2021-05-11'),
(33, 80, 20000, '2021-05-09', '2021-05-09'),
(34, 81, 23000, '2021-05-09', '2021-05-09'),
(35, 82, 30000.5, '2021-05-10', '2021-05-10'),
(36, 83, 30000.5, '2021-05-10', '2021-05-10');

-- --------------------------------------------------------

--
-- Table structure for table `titles`
--

CREATE TABLE `titles` (
  `titles_id` int(11) NOT NULL,
  `emp_no` int(11) NOT NULL,
  `titles` varchar(50) NOT NULL,
  `from_date` date NOT NULL,
  `to_date` date NOT NULL
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4;

--
-- Indexes for dumped tables
--

--
-- Indexes for table `album`
--
ALTER TABLE `album`
  ADD PRIMARY KEY (`id`);

--
-- Indexes for table `departments`
--
ALTER TABLE `departments`
  ADD PRIMARY KEY (`dept_id`);

--
-- Indexes for table `dept_emp`
--
ALTER TABLE `dept_emp`
  ADD PRIMARY KEY (`dept_emp_id`);

--
-- Indexes for table `dept_manager`
--
ALTER TABLE `dept_manager`
  ADD PRIMARY KEY (`dept_manager_id`);

--
-- Indexes for table `employees`
--
ALTER TABLE `employees`
  ADD PRIMARY KEY (`emp_no`);

--
-- Indexes for table `salary`
--
ALTER TABLE `salary`
  ADD PRIMARY KEY (`salary_id`);

--
-- Indexes for table `titles`
--
ALTER TABLE `titles`
  ADD PRIMARY KEY (`titles_id`);

--
-- AUTO_INCREMENT for dumped tables
--

--
-- AUTO_INCREMENT for table `album`
--
ALTER TABLE `album`
  MODIFY `id` int(10) NOT NULL AUTO_INCREMENT, AUTO_INCREMENT=6;

--
-- AUTO_INCREMENT for table `departments`
--
ALTER TABLE `departments`
  MODIFY `dept_id` int(2) NOT NULL AUTO_INCREMENT, AUTO_INCREMENT=17;

--
-- AUTO_INCREMENT for table `dept_emp`
--
ALTER TABLE `dept_emp`
  MODIFY `dept_emp_id` int(3) NOT NULL AUTO_INCREMENT, AUTO_INCREMENT=20;

--
-- AUTO_INCREMENT for table `dept_manager`
--
ALTER TABLE `dept_manager`
  MODIFY `dept_manager_id` int(3) NOT NULL AUTO_INCREMENT;

--
-- AUTO_INCREMENT for table `employees`
--
ALTER TABLE `employees`
  MODIFY `emp_no` int(5) NOT NULL AUTO_INCREMENT, AUTO_INCREMENT=84;

--
-- AUTO_INCREMENT for table `salary`
--
ALTER TABLE `salary`
  MODIFY `salary_id` int(3) NOT NULL AUTO_INCREMENT, AUTO_INCREMENT=37;

--
-- AUTO_INCREMENT for table `titles`
--
ALTER TABLE `titles`
  MODIFY `titles_id` int(11) NOT NULL AUTO_INCREMENT;
COMMIT;

/*!40101 SET CHARACTER_SET_CLIENT=@OLD_CHARACTER_SET_CLIENT */;
/*!40101 SET CHARACTER_SET_RESULTS=@OLD_CHARACTER_SET_RESULTS */;
/*!40101 SET COLLATION_CONNECTION=@OLD_COLLATION_CONNECTION */;

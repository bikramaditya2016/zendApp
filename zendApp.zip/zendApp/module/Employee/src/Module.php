<?php

namespace Employee;

use Zend\ModuleManager\Feature\ConfigProviderInterface;
use Zend\Db\Adapter\AdapterInterface;
use Zend\Db\ResultSet\ResultSet;
use Zend\Db\TableGateway\TableGateway;


class Module implements ConfigProviderInterface
{
    public function getConfig()
    {
        return include __DIR__ . '/../config/module.config.php';
    }
    public function getServiceConfig()
    {
        return [
            'factories' => [
                Model\EmployeeTable::class => function($container) {
                    $tableGateway = $container->get(Model\EmployeeTableGateway::class);
                    return new Model\EmployeeTable($tableGateway);
                },
                Model\EmployeeTableGateway::class => function ($container) {
                    
                    $dbAdapter = $container->get(AdapterInterface::class);                    
                    $resultSetPrototype = new ResultSet();
                    $resultSetPrototype->setArrayObjectPrototype(new Model\Employee());
                    return new TableGateway('employees', $dbAdapter, null, $resultSetPrototype);
                },
                        
                Model\SalaryTable::class => function($container) {
                    $tableGateway = $container->get(Model\SalaryTableGateway::class);
                    return new Model\SalaryTable($tableGateway);
                },
                Model\SalaryTableGateway::class => function ($container) {
                    
                    $dbAdapter = $container->get(AdapterInterface::class);                    
                    $resultSetPrototype = new ResultSet();
                    $resultSetPrototype->setArrayObjectPrototype(new Model\Salary());
                    return new TableGateway('salary', $dbAdapter, null, $resultSetPrototype);
                },
                        
                Model\Dept_empTable::class => function($container) {
                    $tableGateway = $container->get(Model\Dept_empTableGateway::class);
                    return new Model\Dept_empTable($tableGateway);
                },
                Model\Dept_empTableGateway::class => function ($container) {
                    
                    $dbAdapter = $container->get(AdapterInterface::class);                    
                    $resultSetPrototype = new ResultSet();
                    $resultSetPrototype->setArrayObjectPrototype(new Model\Dept_emp());
                    return new TableGateway('dept_emp', $dbAdapter, null, $resultSetPrototype);
                },

            ],
        ];
    }
    public function getControllerConfig()
    {
        return [
            'factories' => [
                Controller\EmployeeController::class => function($container) {
                    return new Controller\EmployeeController(
                        $container->get(Model\EmployeeTable::class),
                        $container->get(Model\SalaryTable::class),
                        $container->get(Model\Dept_empTable::class)
                    );
                }
//                Model\Salary::class => function($container) {
//                    return new Model\Salary(
//                        $container->get(Model\SalaryTable::class)
//                    );
//                },
                 
            ],
        ];
    }
}
?>
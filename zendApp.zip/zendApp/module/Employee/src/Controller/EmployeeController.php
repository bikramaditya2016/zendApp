<?php
namespace Employee\Controller;


use Zend\Mvc\Controller\AbstractActionController;
use Zend\View\Model\ViewModel;

use Employee\Model\EmployeeTable;
use Employee\Model\SalaryTable;
use Employee\Model\Dept_empTable;

use Employee\Model\Employee;
use Employee\Form\EmployeeForm;



class EmployeeController extends AbstractActionController
{
    private $table;
    private $table_salary;
    private $table_dept_emp;


    public function __construct(
            EmployeeTable $table,
            SalaryTable $table_salary, 
            Dept_empTable $table_dept_emp)
    {
        $this->table = $table;
        $this->table_salary = $table_salary;
        $this->table_dept_emp = $table_dept_emp;
         
       
    }
    public function indexAction()
    {
        return new ViewModel([
            'employee' => $this->table->fetchAll(),
        ]);
    }

    public function addAction()
    {
        
        $id = (int) $this->params()->fromRoute('id', 0); 
        $data = array();
        if ($id > 0) {
            $data = $this->table->getEmployee($id);            
          
        }
        $form = new EmployeeForm();
        
      
        $form->get('submit')->setValue('Submit');
        $request = $this->getRequest();        
        

        if (! $request->isPost()) {
            return ['form' => $form, 
                'dep' => $this->table->fetchDept(),
                'data' => $data
                    ];
        }

        $employee = new Employee();
        $form->setInputFilter($employee->getInputFilter());
        $form->setData($request->getPost());

        
        
        if (! $form->isValid()) {
            return ['form' => $form, 'dep' => $this->table->fetchDept()];
        }

           
        $employee->exchangeArray($form->getData());
        
        $employee = $this->table->saveEmployee($employee);
                

        $this->table_salary->saveSalary ($employee);
        $this->table_dept_emp->saveDept_emp ($employee);
        
        return $this->redirect()->toRoute('employee', ['action' => 'view', 'id'=>0]);
        
    }

    public function viewAction()
    {
        $page_no = (int) $this->params()->fromRoute('id', 0);

        return new ViewModel([
            'albums' => $this->table->fetchAllPaginate($page_no),
            'page_no' => (int)$page_no
        ]);
    }
    public function editAction()
    {
        $id = (int) $this->params()->fromRoute('id', 0);

        if (0 === $id) {
            return $this->redirect()->toRoute('employee', ['action' => 'add']);
        }

        // Retrieve the album with the specified id. Doing so raises
        // an exception if the album is not found, which should result
        // in redirecting to the landing page.
        try {
            $employee = $this->table->getEmployee($id);
        } catch (\Exception $e) {
            return $this->redirect()->toRoute('employee', ['action' => 'index']);
        }

        $form = new EmployeeForm();
        $form->bind($employee);
        $form->get('submit')->setAttribute('value', 'Edit');

        $request = $this->getRequest();
        $viewData = ['id' => $id, 'form' => $form, 'dep' => $this->table->fetchDept()];

        if (! $request->isPost()) {
            return $viewData;
        }

        $form->setInputFilter($employee->getInputFilter());
        $form->setData($request->getPost());
        
        

        if (! $form->isValid()) {
            return $viewData;
        }
        
//                echo '<pre>';
//        var_dump($form);
//        exit();

//        $this->table->saveAlbum($employee);
        
        $this->table->saveEmployee($employee);                

        $this->table_salary->saveSalary ($employee);
        $this->table_dept_emp->saveDept_emp ($employee);

        // Redirect to album list
        return $this->redirect()->toRoute('employee', ['action' => 'view', 'id'=>0]);

       
    }

    public function deleteAction()
    {
        $id = (int) $this->params()->fromRoute('id', 0);
        if (!$id) {
            return $this->redirect()->toRoute('employee');
        }
        $this->table->deleteEmployee($id);
        return $this->redirect()->toRoute('employee', ['action' => 'view', 'id'=>0]);
    }
}


?>

<?php

namespace Employee\Form;

use Zend\Form\Form;

class EmployeeForm extends Form
{
    public function __construct($name = null)
    {
        // We will ignore the name provided to the constructor
        parent::__construct('salary');

         $this->add([
            'name' => 'emp_no',
            'type' => 'hidden',
        ]);
        $this->add([
            'name' => 'first_name',
            'type' => 'text',            
            'options' => [
                'label' => 'Employee First Name :',
                
            ],
        ]);
        $this->add([
            'name' => 'last_name',
            'type' => 'text',
            'options' => [
                'label' => 'Last Name :',
            ],
        ]);
        $this->add([
            'name' => 'birth_date',
            'type' => 'date',
            'options' => [
                'label' => 'Birth Date :',
            ],
        ]);
        $this->add([
            'name' => 'hire_date',
            'type' => 'date',
            'options' => [
                'label' => 'Hire Date :',
            ],
        ]);
        $this->add([
            'name' => 'from_date',
            'type' => 'date',
            'options' => [
                'label' => 'From Date :',
            ],
        ]);
        $this->add([
            'name' => 'to_date',
            'type' => 'date',
            'options' => [
                'label' => 'To Date :',
            ],
        ]);
        
        $this->add([
            'name' => 'titles',
            'type' => 'text',
            'options' => [
                'label' => 'Titles :',
            ],
        ]);
        
        $this->add([
            'name' => 'salary',
            'type' => 'text',
            'options' => [
                'label' => 'Salary :',
            ],
        ]);
        
        $this->add([
            'name' => 'submit',
            'type' => 'submit',
            'attributes' => [
                'value' => 'Go',
                'id'    => 'submitbutton',
            ],
        ]);
    }
}

?>
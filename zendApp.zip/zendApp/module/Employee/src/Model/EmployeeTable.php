<?php
namespace Employee\Model;

use RuntimeException;
use Zend\Db\TableGateway\TableGatewayInterface;
use Zend\Db\Sql\Select;
use Zend\Db\Sql\Insert;
use Zend\Db\Sql\Update;
use Zend\Db\Sql;

use Employee\Model\SalaryTable;

class EmployeeTable extends SalaryTable
{
    private $tableGateway;
    

    public function __construct(TableGatewayInterface $tableGateway)
    {
        $this->tableGateway = $tableGateway;
        
//        echo '<pre>';
//        var_dump($this->tableGateway);
        
    }

    public function fetchAll()
    {
        return $this->tableGateway->select();
    }

    public function getEmployee($id)
    {
        $id = (int) $id;
        
        $select = new Select();       //CHANGE TABLE_NAME as per needs
        $select->from( 'employees' );        
        $select->join('dept_emp', 'employees.emp_no = dept_emp.emp_no', ["dept_id","from_date", "to_date"], 'left');
        $select->join('departments', 'dept_emp.dept_id = departments.dept_id', ["dept_no","dept_name"], 'left');
        $select->join('salary', 'employees.emp_no = salary.emp_no', ["salary", "from_date", "to_date"], 'left');
        $select->where('employees.emp_no = ' . $id);
       
        $resultSet = $this->tableGateway->selectWith($select);  //Will get array of rows.

        //$row = $rowset->current(); THIS IS FOR RETURNING ONLY SINGLE ROW NOT ALL ROWS
        
        
//        $rowset = $this->tableGateway->select(['id' => $id]);
        $row = $resultSet->current();
        if (! $row) {
            throw new RuntimeException(sprintf(
                'Could not find row with identifier %d',
                $id
            ));
        }

        return $row;
    }

    public function saveEmployee(Employee $employee)
    {
        $data = [
            'birth_date'    => $employee->birth_date,
            'first_name'    => $employee->first_name,
            'last_name'     => $employee->last_name,
            'gender'        => $employee->gender,
            'hire_date'     => $employee->hire_date           
        ];

        $id = (int) $employee->emp_no;

        if ($id === 0) {
            
            $employee->flag = 'add';
            $this->tableGateway->insert($data);
            
            $employee->emp_no = $this->tableGateway->lastInsertValue;
            return $employee;
        }
        try {
//            $this->getAlbum($id);
        } catch (RuntimeException $e) {
            throw new RuntimeException(sprintf(
                'Cannot update album with identifier %d; does not exist',
                $id
            ));
        }
        $this->tableGateway->update($data, ['emp_no' => $id]);
    }

    public function deleteEmployee($id)
    {
        $this->tableGateway->delete(['emp_no' => (int) $id]);
    }
    public function fetchDept() {
         
        $select = new Select("departments");       //CHANGE TABLE_NAME as per needs

        $resultSet = $this->tableGateway->selectWith($select);  //Will get array of rows.

        //$row = $rowset->current(); THIS IS FOR RETURNING ONLY SINGLE ROW NOT ALL ROWS

        if (!$resultSet) {
            throw new \Exception("Could not find rows with food id - $id");
        }
        return $resultSet;
    }
    public function fetchAllPaginate($page_no)
    {
//         $postId = $this->params()->fromRoute('postId');
       
        
//        var_dump($page_no);
        $limit = 3;
        $offset = $page_no * $limit;
        $select = new Select();       //CHANGE TABLE_NAME as per needs
        $select->from( 'employees' );        
        $select->join('dept_emp', 'employees.emp_no = dept_emp.emp_no', ["dept_id","from_date", "to_date"], 'left');
        $select->join('departments', 'dept_emp.dept_id = departments.dept_id', ["dept_no","dept_name"], 'left');
        $select->join('salary', 'employees.emp_no = salary.emp_no', ["salary", "from_date", "to_date"], 'left');
//        $select->where('emp_no = ' . $id);
        $select->order('employees.emp_no Desc');
        $select->offset($offset);
        $select->limit($limit);

//        echo '<pre>';
//        var_dump($select);
        $resultSet = $this->tableGateway->selectWith($select);  //Will get array of rows.

        //$row = $rowset->current(); THIS IS FOR RETURNING ONLY SINGLE ROW NOT ALL ROWS

        if (!$resultSet) {
            throw new \Exception("Could not find rows with food id - $id");
        }
        return $resultSet;       

    }
}

?>
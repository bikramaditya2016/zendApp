<?php
namespace Employee\Model;

use RuntimeException;
use Zend\Db\TableGateway\TableGatewayInterface;
use Zend\Db\Sql\Select;
use Zend\Db\Sql\Insert;


class Dept_empTable 
{
    private $tableGateway;

    public function __construct(TableGatewayInterface $tableGateway)
    {
        $this->tableGateway = $tableGateway;
        
       
    } 
    public function saveDept_emp (Employee $employee) {
        
         $data = [
            'emp_no'    => $employee->emp_no,
            'dept_id'    => $employee->dept_id,
            'from_date' => $employee->from_date,
            'to_date'   => $employee->to_date             
        ];


        if ($employee->flag === "add") {
            $this->tableGateway->insert($data);
            return;
        }
        $this->tableGateway->update($data, ['emp_no' => $employee->emp_no]);
        
       
    }
}

?>
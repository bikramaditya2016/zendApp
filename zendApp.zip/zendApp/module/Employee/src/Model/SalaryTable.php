<?php
namespace Employee\Model;

use RuntimeException;
use Zend\Db\TableGateway\TableGatewayInterface;
use Zend\Db\Sql\Select;
use Zend\Db\Sql\Insert;


class SalaryTable 
{
    private $tableGateway;

    public function __construct(TableGatewayInterface $tableGateway)
    {
        $this->tableGateway = $tableGateway;
        
       
    } 
    public function saveSalary (Employee $employee) {
        
         $data = [
            'emp_no'    => $employee->emp_no,
            'salary'    => $employee->salary,
            'from_date' => $employee->from_date,
            'to_date'   => $employee->to_date             
        ];


        if ($employee->flag === "add") {
            $this->tableGateway->insert($data);
            return;
        }
        $this->tableGateway->update($data, ['emp_no' => $employee->emp_no]);
        
       
    }
}

?>
<?php

namespace Employee\Model;

use DomainException;
use Zend\Filter\StringTrim;
use Zend\Filter\StripTags;
use Zend\Filter\ToInt;
use Zend\InputFilter\InputFilter;
use Zend\InputFilter\InputFilterAwareInterface;
use Zend\InputFilter\InputFilterInterface;
use Zend\Validator\StringLength;


use Zend\Db\TableGateway\TableGatewayInterface;
use Zend\Db\Sql\Insert;


use Employee\Model\SalaryTable;
class Salary 
{
   
    public function exchangeArray(array $data)
    {
       
    }
    
}

?>
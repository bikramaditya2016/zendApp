<?php

namespace Employee\Model;

use DomainException;
use Zend\Filter\StringTrim;
use Zend\Filter\StripTags;
use Zend\Filter\ToInt;
use Zend\InputFilter\InputFilter;
use Zend\InputFilter\InputFilterAwareInterface;
use Zend\InputFilter\InputFilterInterface;
use Zend\Validator\StringLength;


use Zend\Db\TableGateway\TableGatewayInterface;
use Zend\Db\Sql\Insert;

class Employee
{
    public $flag;
    public $emp_no;
    public $birth_date;
    public $first_name;
    public $last_name;
    public $gender;
    public $hire_date;
    public $dept_id;
    public $dept_name;
    public $dept_no;
    public $titles; 
    public $salary; 
    public $to_date;
    public $from_date;
    
    private $inputFilter;

    public function exchangeArray(array $data)
    {

        $this->emp_no     = !empty($data['emp_no']) ? $data['emp_no'] : null;
        $this->birth_date = !empty($data['birth_date']) ? $data['birth_date'] : null;
        $this->first_name = !empty($data['first_name']) ? $data['first_name'] : null;
        $this->last_name  = !empty($data['last_name']) ? $data['last_name'] : null;
        $this->gender     = !empty($data['gender']) ? $data['gender'] : null;
        $this->hire_date  = !empty($data['hire_date']) ? $data['hire_date'] : null;
        $this->dept_id    = !empty($data['dept_id']) ? $data['dept_id'] : null;
        $this->dept_no    = !empty($data['dept_no']) ? $data['dept_no'] : null;
        $this->dept_name  = !empty($data['dept_name']) ? $data['dept_name'] : null;
        $this->titles     = !empty($data['titles']) ? $data['titles'] : null;
        $this->salary     = !empty($data['salary']) ? $data['salary'] : null;
        $this->to_date    = !empty($data['to_date']) ? $data['to_date'] : null;
        $this->from_date  = !empty($data['from_date']) ? $data['from_date'] : null;
    }
    public function getArrayCopy()
    {
        return [
            'emp_no'        => $this->emp_no,
            'birth_date'    => $this->birth_date,
            'first_name'    => $this->first_name,            
            'last_name'     => $this->last_name,
            'gender'        => $this->gender,
            'hire_date'     => $this->hire_date,            
            'dept_id'       => $this->dept_id,
            'dept_no'       => $this->dept_no,
            'dept_name'     => $this->dept_name,            
            'titles'        => $this->titles,
            'salary'        => $this->salary,
            'to_date'       => $this->to_date,
            'from_date'     => $this->from_date
        ];
    }
    
     public function setInputFilter(InputFilterInterface $inputFilter)
    {
        throw new DomainException(sprintf(
            '%s does not allow injection of an alternate input filter',
            __CLASS__
        ));
    }

    public function getInputFilter()
    {
        if ($this->inputFilter) {
            return $this->inputFilter;
        }

        $inputFilter = new InputFilter();

         $inputFilter->add([
            'name' => 'flag',
            'required' => false,
            'filters' => [
                ['name' => ToInt::class],
            ],
        ]);
         
        $inputFilter->add([
            'name' => 'emp_no',
            'required' => false,
            'filters' => [
                ['name' => ToInt::class],
            ],
        ]);

        $inputFilter->add([
            'name' => 'first_name',
            'required' => true,
            'filters' => [
                ['name' => StripTags::class],
                ['name' => StringTrim::class],
            ],
            'validators' => [
                [
                    'name' => StringLength::class,
                    'options' => [
                        'encoding' => 'UTF-8',
                        'min' => 1,
                        'max' => 100,
                    ],
                ],
            ],
        ]);

        $inputFilter->add([
            'name' => 'last_name',
            'required' => true,
            'filters' => [
                ['name' => StripTags::class],
                ['name' => StringTrim::class],
            ],
            'validators' => [
                [
                    'name' => StringLength::class,
                    'options' => [
                        'encoding' => 'UTF-8',
                        'min' => 1,
                        'max' => 100,
                    ],
                ],
            ],
        ]);
        $inputFilter->add([
            'name' => 'birth_date',
            'required' => false,
            'filters' => [
                ['name' => StripTags::class],
                ['name' => StringTrim::class],
            ],
            'validators' => [
                [
                    'name' => StringLength::class,
                    'options' => [
                        'encoding' => 'UTF-8',
                        'min' => 1,
                        'max' => 50,
                    ],
                ],
            ],
        ]);
        $inputFilter->add([
            'name' => 'gender',
            'required' => false,
            'filters' => [
                ['name' => StripTags::class],
                ['name' => StringTrim::class],
            ],
            'validators' => [
                [
                    'name' => StringLength::class,
                    'options' => [
                        'encoding' => 'UTF-8',
                        'min' => 1,
                        'max' => 10,
                    ],
                ],
            ],
        ]);
        $inputFilter->add([
            'name' => 'hire_date',
            'required' => false,
            'filters' => [
                ['name' => StripTags::class],
                ['name' => StringTrim::class],
            ],
            'validators' => [
                [
                    'name' => StringLength::class,
                    'options' => [
                        'encoding' => 'UTF-8',
                        'min' => 1,
                        'max' => 20,
                    ],
                ],
            ],
        ]);
        
        $inputFilter->add([
            'name' => 'dept_id',
            'required' => false,
            'filters' => [
                ['name' => StripTags::class],
                ['name' => StringTrim::class],
            ],
            'validators' => [
                [
                    'name' => StringLength::class,
                    'options' => [
                        'encoding' => 'UTF-8',
                        'min' => 1,
                        'max' => 10,
                    ],
                ],
            ],
        ]);
        $inputFilter->add([
            'name' => 'from_date',
            'required' => false,
            'filters' => [
                ['name' => StripTags::class],
                ['name' => StringTrim::class],
            ],
            'validators' => [
                [
                    'name' => StringLength::class,
                    'options' => [
                        'encoding' => 'UTF-8',
                        'min' => 1,
                        'max' => 10,
                    ],
                ],
            ],
        ]);
        
        $inputFilter->add([
            'name' => 'to_date',
            'required' => false,
            'filters' => [
                ['name' => StripTags::class],
                ['name' => StringTrim::class],
            ],
            'validators' => [
                [
                    'name' => StringLength::class,
                    'options' => [
                        'encoding' => 'UTF-8',
                        'min' => 1,
                        'max' => 10,
                    ],
                ],
            ],
        ]);
        
        $inputFilter->add([
            'name' => 'salary',
            'required' => false,
            'filters' => [
                ['name' => StripTags::class],
                ['name' => StringTrim::class],
            ],
            'validators' => [
                [
                    'name' => StringLength::class,
                    'options' => [
                        'encoding' => 'UTF-8',
                        'min' => 1,
                        'max' => 10,
                    ],
                ],
            ],
        ]);
        $inputFilter->add([
            'name' => 'titles',
            'required' => false,
            'filters' => [
                ['name' => StripTags::class],
                ['name' => StringTrim::class],
            ],
            'validators' => [
                [
                    'name' => StringLength::class,
                    'options' => [
                        'encoding' => 'UTF-8',
                        'min' => 1,
                        'max' => 10,
                    ],
                ],
            ],
        ]);
        
        
        $this->inputFilter = $inputFilter;
        return $this->inputFilter;
    }
    
}

?>
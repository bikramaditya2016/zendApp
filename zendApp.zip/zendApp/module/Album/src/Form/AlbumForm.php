<?php

namespace Album\Form;
use Zend\Form\Form;

class AlbumForm extends Form {
    
    public function __construct($name = null)
    {
        // We will ignore the name provided to the constructor
        parent::__construct('album');
        
//        $this->setAttribute('method', 'GET');

        $this->add([
            'name' => 'emp_no',
            'type' => 'hidden',
        ]);
        $this->add([
            'name' => 'birth_date',
            'type' => 'text',
            'options' => [
                'label' => 'birth date',
            ],
        ]);
        $this->add([
            'name' => 'first_name',
            'type' => 'text',
            'options' => [
                'label' => 'first name',
            ],
        ]);
        $this->add([
            'name' => 'last_name',
            'type' => 'text',
            'options' => [
                'label' => 'last name',
            ],
        ]);
        
        $this->add([
            'name' => 'gender',
            'type' => 'text',
            'options' => [
                'label' => 'gender',
            ],
        ]);
        $this->add([
            'name' => 'submit',
            'type' => 'submit',
            'attributes' => [
                'value' => 'Go',
                'id'    => 'submitbutton',
            ],
        ]);
    }
}
?>
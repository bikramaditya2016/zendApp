<?php

namespace Album\Controller;

use Album\Model\AlbumTable;
use Album\Model\SalaryTable;

use Zend\Mvc\Controller\AbstractActionController;
use Zend\View\Model\ViewModel;
use Album\Form\AlbumForm;
use Album\Model\Album;
use Album\Model\Salary;




class AlbumController extends AbstractActionController
{
    private $table;
    private $salaryTable;
     public function __construct(AlbumTable $table)
    {
        $this->table = $table;
       
        
       
    }
    public function indexAction()
    {
        return new ViewModel([
            'albums' => $this->table->fetchAll(),
        ]);
        
        
    }
    
    public function pageAction()
    {       
        $page_no = (int) $this->params()->fromRoute('id', 0);

        return new ViewModel([
            'albums' => $this->table->fetchAllPaginate($page_no),
            'page_no' => (int)$page_no
        ]);
    }

    public function addAction()
    {
        $form = new AlbumForm();
        $form->get('submit')->setValue('Add');

        $request = $this->getRequest();

        if (! $request->isPost()) {
            return ['form' => $form,
                    'dep' => $this->table->fetchDept(),
                ];
        }

        $album = new Album();
        $form->setInputFilter($album->getInputFilter());
        $form->setData($request->getPost());

        if (! $form->isValid()) {
            return ['form' => $form,
                'dep' => $this->table->fetchDept()
                ];
        }

        $album->exchangeArray($form->getData());
        
        
        $this->table->saveAlbum($album);
        
       
        
//        return $this->redirect()->toRoute('album');
    }

    public function editAction()
    {
    }

    public function deleteAction()
    {
    }
}

?>
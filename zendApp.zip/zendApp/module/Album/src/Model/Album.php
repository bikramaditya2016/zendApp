<?php

namespace Album\Model;

use DomainException;
use Zend\Filter\StringTrim;
use Zend\Filter\StripTags;
use Zend\Filter\ToInt;
use Zend\InputFilter\InputFilter;
use Zend\InputFilter\InputFilterAwareInterface;
use Zend\InputFilter\InputFilterInterface;
use Zend\Validator\StringLength;


class Album implements InputFilterAwareInterface
{
    public $id;
//    public $artist;
//    public $title;
    
    public $emp_no;
    public $birth_date;
    public $first_name;
    public $last_name;
    public $gender;
    public $hire_date;
    public $dept_no;
    public $dept_name;
    


    private $inputFilter;
   

    public function exchangeArray(array $data)
    {   
        $this->id     = !empty($data['id']) ? $data['id'] : null;
//        $this->artist = !empty($data['artist']) ? $data['artist'] : null;
//        $this->title  = !empty($data['title']) ? $data['title'] : null;
        
        $this->emp_no       = !empty($data['emp_no']) ? $data['emp_no'] : null;
        $this->birth_date   = !empty($data['birth_date']) ? $data['birth_date'] : null;
        $this->first_name   = !empty($data['first_name']) ? $data['first_name'] : null;
        $this->last_name    = !empty($data['last_name']) ? $data['last_name'] : null;
        $this->gender       = !empty($data['gender']) ? $data['gender'] : null;
        $this->hire_date    = !empty($data['hire_date']) ? $data['hire_date'] : null;
        $this->dept_no       = !empty($data['dept_no']) ? $data['dept_no'] : null;
        $this->dept_name    = !empty($data['dept_name']) ? $data['dept_name'] : null;
    }
    
    public function setInputFilter(InputFilterInterface $inputFilter)
    {
        throw new DomainException(sprintf(
            '%s does not allow injection of an alternate input filter',
            __CLASS__
        ));
    }

    public function getInputFilter()
    {
        if ($this->inputFilter) {
            return $this->inputFilter;
        }

        $inputFilter = new InputFilter();

        $inputFilter->add([
            'name' => 'id',
            'required' => false,
            'filters' => [
                ['name' => ToInt::class],
            ],
        ]);

        $inputFilter->add([
            'name' => 'first_name',
            'required' => true,
            'filters' => [
                ['name' => StripTags::class],
                ['name' => StringTrim::class],
            ],
            'validators' => [
                [
                    'name' => StringLength::class,
                    'options' => [
                        'encoding' => 'UTF-8',
                        'min' => 1,
                        'max' => 100,
                    ],
                ],
            ],
        ]);

        $inputFilter->add([
            'name' => 'last_name',
            'required' => true,
            'filters' => [
                ['name' => StripTags::class],
                ['name' => StringTrim::class],
            ],
            'validators' => [
                [
                    'name' => StringLength::class,
                    'options' => [
                        'encoding' => 'UTF-8',
                        'min' => 1,
                        'max' => 100,
                    ],
                ],
            ],
        ]);
        
        $inputFilter->add([
            
            'name' => 'gender',
            'required' => true,
            'filters' => [
                ['name' => StripTags::class],
                ['name' => StringTrim::class],
            ],
            'validators' => [
                [
                    'name' => StringLength::class,
                    'options' => [
                        'encoding' => 'UTF-8',
                        'min' => 1,
                        'max' => 100,
                       
                    ],
                ],
            ],
        ]);

        
//         $inputFilter->add([
//            
//            'name' => 'hire_date',
//            'required' => false,
//            'filters' => [
//                ['name' => StripTags::class],
//                ['name' => StringTrim::class],
//            ],
//            'validators' => [
//                [
//                    'name' => StringLength::class,
//                    'options' => [
//                        'encoding' => 'UTF-8',
//                        'min' => 1,
//                        'max' => 100,
//                       
//                    ],
//                ],
//            ],
//        ]);

        $this->inputFilter = $inputFilter;
        return $this->inputFilter;
    }

}

?>
<?php

namespace Salary\Model;

class Salary
{
    public $emp_no;
    public $salary;
    public $from_date;
    public $to_date;

    public function exchangeArray(array $data)
    {
        $this->emp_no   = !empty($data['emp_no']) ? $data['emp_no'] : null;
        $this->salary   = !empty($data['salary']) ? $data['salary'] : null;
        $this->from_date= !empty($data['from_date']) ? $data['from_date'] : null;
        $this->to_date  = !empty($data['to_date']) ? $data['to_date'] : null;
    }
}

?>

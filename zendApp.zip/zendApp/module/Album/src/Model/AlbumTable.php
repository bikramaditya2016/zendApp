<?php

namespace Album\Model;

use RuntimeException;
use Zend\Db\TableGateway\TableGatewayInterface;
use Zend\Db\Sql\Select;
use Zend\Db\Sql\Insert;


class AlbumTable 
{
    private $tableGateway;

    public function __construct(TableGatewayInterface $tableGateway)
    {
        $this->tableGateway = $tableGateway;
        
        
    }

    public function fetchAll()
    {
       
        return $this->tableGateway->select();
    }
    
     public function fetchAllPaginate($page_no)
    {
//         $postId = $this->params()->fromRoute('postId');
       
        
//        var_dump($page_no);
        $limit = 3;
        $offset = $page_no * $limit;
        $select = new Select();       //CHANGE TABLE_NAME as per needs
        $select->from( 'employees' );
        $select->join('departments', 'employees.emp_no = departments.emp_no');
//        $select->where('emp_no = ' . $id);
        $select->order('employees.emp_no ASC');
        $select->offset($offset);
        $select->limit($limit);


        $resultSet = $this->tableGateway->selectWith($select);  //Will get array of rows.

        //$row = $rowset->current(); THIS IS FOR RETURNING ONLY SINGLE ROW NOT ALL ROWS

        if (!$resultSet) {
            throw new \Exception("Could not find rows with food id - $id");
        }
        return $resultSet;
       

    }

    public function getAlbum($id)
    {
        $id = (int) $id;
        $rowset = $this->tableGateway->select(['id' => $id]);
        $row = $rowset->current();
        if (! $row) {
            throw new RuntimeException(sprintf(
                'Could not find row with identifier %d',
                $id
            ));
        }

        return $row;
    }

    public function saveAlbum(Album $album)
    {
        
        echo '<pre>';
//        var_dump($album);
//        exit();
        
        
        $data = [
            'birth_date' => $album->birth_date,
            'first_name'  => $album->first_name,
            'last_name' => $album->last_name,
            'gender'  => $album->gender            
        ];

        $id = (int) $album->id;

        if ($id === 0) {
            $insert_res = $this->tableGateway->insert($data);
            
           
        $select = new Select();       //CHANGE TABLE_NAME as per needs
        $select->from( 'employees' ); 
        $select->order('employees.emp_no DESC');
        $select->limit(1);


        $resultSet = $this->tableGateway->selectWith($select);  //Will get array of rows.

        $row = $resultSet->current(); // THIS IS FOR RETURNING ONLY SINGLE ROW NOT ALL ROWS
        
        $emp_no = $row->emp_no;
        echo '<pre>';
        var_dump($emp_no);
        
    echo '<pre>';
        
        $insert = new Insert("employees");
        $insert->values(array("first_name"=>"10", "last_name"=>"10000"));

         $resultSet = $this->tableGateway->insertWith($insert);
var_dump($results);
        
//            return;
        }

//        try {
//            $this->getAlbum($id);
//        } catch (RuntimeException $e) {
//            throw new RuntimeException(sprintf(
//                'Cannot update album with identifier %d; does not exist',
//                $id
//            ));
//        }
        
//        $last_id = $tablemodel->getAdapter()->lastInsertId();
       
       

//        $this->tableGateway->update($data, ['id' => $id]);
        
        
    }

    public function deleteAlbum($id)
    {
        $this->tableGateway->delete(['id' => (int) $id]);
    }
    public function fetchDept() {
         
        $select = new Select("departments");       //CHANGE TABLE_NAME as per needs
//        $select->from( 'employees' );
//        
////        $select->where('emp_no = ' . $id);
//        $select->order('employees.emp_no ASC');
//        $select->offset($offset);
//        $select->limit($limit);


        $resultSet = $this->tableGateway->selectWith($select);  //Will get array of rows.

        //$row = $rowset->current(); THIS IS FOR RETURNING ONLY SINGLE ROW NOT ALL ROWS

        if (!$resultSet) {
            throw new \Exception("Could not find rows with food id - $id");
        }
        return $resultSet;
    }
}

?>